import numpy as np
##set random seed before import of keras moduls
np.random.seed(229156044)

from keras.callbacks import CSVLogger, EarlyStopping, ModelCheckpoint
from keras.models import Sequential
from keras.layers import Dense
from keras import backend as K
from keras import optimizers
from keras.layers import Dropout
from keras.models import load_model
import os.path
import json
from sklearn.utils import shuffle
import tensorflow as tf 
from sklearn.metrics import mean_absolute_error, mean_squared_error

batchsize = 256
learning_rates = [0.001, 0.0001]
#number of vertices in each graph
graphsizes = [10,11,12]
#number of samples for each size
samplesize = 50000
#set to dense9, dense 5 or sparse1
connection_types = ["sparse1", "dense5", "dense9", "mixed"]
epochs =  2000 #at most

samplesize_dict = {
    0 : 128,
    1 : 250,
    2 : 500,
    3 : 1000,
    4 : 2000,
    5 : 4000,
    6 : 8000,
    7 : 16000,
    8 : 32000,
    9 : 64000,
    10 : 128000,
    11: 256000,
    12: -1
}


def ensure_dir(directory):
    print(directory)
    if not os.path.exists(directory):
        os.makedirs(directory)

def soft_acc(y_true, y_pred):
    y_true = tf.exp(y_true)
    y_pred = tf.exp(y_pred)
    return K.mean(K.equal(K.round(y_true), K.round(y_pred)))


path_output_root = os.path.join(os.path.dirname(os.getcwd()), "Output", "samplesizeFFN_logscale")
ensure_dir(path_output_root)


for connection_type in connection_types:
    print("Start experiments for connection type: {}".format(connection_type))
    path_output = os.path.join(path_output_root, connection_type)
    ensure_dir(path_output)

    path_data = os.path.join(os.path.join(os.path.dirname(os.getcwd()), "Data"), str(connection_type))
    filename = "ER_ECCN_padded_" + str(connection_type) + "_" + str(graphsizes) + "_" + str(samplesize)

    X = np.load(os.path.join(path_data, filename + "_X.npy"))
    y = np.load(os.path.join(path_data, filename + "_y.npy"))

    X, y = shuffle(X, y, random_state=42)

    if connection_type == "sparse1" or connection_type == "mixed":
        y = np.add(y,1)

    y = np.log(y)

    ##shape inputs to single graphsize**2-dimensional vectors, i.e. no time steps and one feature
    X = np.reshape(X, (X.shape[0], X.shape[1] * X.shape[2]))

    ##split data (0.7,0.1,0.2)
    split_train = int(.7 * len(y))
    split_validation = int(.1 * len(y)) + split_train

    X_train = X[:split_train]
    y_train = y[:split_train]

    X_validation = X[split_train:split_validation]
    y_validation = y[split_train:split_validation]

    X_test = X[split_validation:]
    y_test = y[split_validation:]

    for step in range(13):
        samples = samplesize_dict[step]

        if (not connection_type == "mixed") and step  == 10:
            samples = len(y_train)
        if (not connection_type == "mixed") and step > 10:
            continue
        if connection_type == "mixed" and step == 12:
            samples = len(y_train)

        print("Training samples used {}".format(samples))

        best_score = -1
        best = []

        for learning_rate in learning_rates:
            print("check LR = {}".format(learning_rate))
            ##optimizer: adam
            opt = optimizers.Adam(lr=learning_rate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)
            model = Sequential()
            model.add(Dense(512, input_shape=(12 * 12,), activation='relu'))
            model.add(Dropout(0.1))
            model.add(Dense(256, activation='relu'))
            model.add(Dropout(0.1))
            model.add(Dense(1,activation = None))
            model.summary()

            early_stop = EarlyStopping(monitor='val_soft_acc',
                                       min_delta=0,
                                       patience=20,
                                       verbose=0,
                                       mode='max')
            bestmodelname = os.path.join(path_output, '{}_{}_bestmodel.h5'.format(samples,learning_rate))
            save_best = ModelCheckpoint(bestmodelname,
                                        monitor='val_soft_acc',
                                        verbose=0,
                                        save_best_only=True,
                                        mode='max')
            ##train model
            model.compile(optimizer=opt,
                          loss='mean_squared_error',
                          metrics=['mean_absolute_error', soft_acc])

            model.fit(X_train[:samples],
                      y_train[:samples],
                      epochs = epochs,
                      batch_size = batchsize,
                      validation_data = (X_validation,y_validation),
                      verbose = 2,
                      shuffle = True,
                      callbacks = [ save_best, early_stop])

            ##load best_model
            best_model = load_model(bestmodelname, custom_objects={'soft_acc': soft_acc})

            curr_score = best_model.evaluate(X_test, y_test)[2]
            print("scored {}".format(curr_score))
            if best_score < curr_score:
                ##scores of the best model
                best_score = curr_score
                y_pred = np.exp(best_model.predict(X_test))
                mse = mean_squared_error(np.exp(y_test), y_pred)
                mae = mean_absolute_error(np.exp(y_test), y_pred)
                best_score = curr_score
                best = [best_model.evaluate(X_train[:samples], y_train[:samples]),
                        best_model.evaluate(X_train, y_train),
                        best_model.evaluate(X_validation, y_validation),
                        best_model.evaluate(X_test, y_test),
                        mae,
                        mse]
            os.remove(bestmodelname)

        with open(os.path.join(path_output, '{}_performance.log'.format(samples)), "w") as fp:
            json.dump(best, fp)

