import numpy as np
import random
import os.path
import json
import time
from multiprocessing import Pool
from functions_graphs import rand_graph_erp, ECCN_from_adj

#set random seed
random.seed(291416)

#print whole arrays
np.set_printoptions(threshold=np.nan)

if __name__ == '__main__':
    
    ##variable
    #number of nodes in each graph, takes a list
    graphsizes = [13]
    #number of samples for each size
    samplesize = 100
    #set to dense9, dense 5 or sparse1
    connection_type = "dense9"
    connection_prob = 0.9
    
###############################################################################
    
    #outputfile
    filenames = ["ER_ECCN_" + str(connection_type) + "_" + str(graphsize) + "_" + str(samplesize) for graphsize in graphsizes]
    path_data = os.path.join(os.path.join(os.path.dirname(os.getcwd()),"Data"), str(connection_type))
    
    for i in range(len(graphsizes)):
        ##generate data
        nodes = graphsizes[i]
        filename = filenames[i]
        
        #set time counter
        start_time = time.time()
        
        #generate graphs
        X = [list(rand_graph_erp(nodes, connection_prob, directed=False)) for _ in range(samplesize)]
        
        time_now = time.time()
        
        #parallel computing for ECCNs 
        pool = Pool(processes=1)
        data = pool.starmap(ECCN_from_adj, [[graph] for graph in X])
        pool.close()
        pool.join()
        
        #time stamp for data generation        
        time_now2 = time.time()
        
        graph_time = time_now - start_time
        eccn_time = time_now2 - time_now
        
        #write data to file
        with open(os.path.join(path_data,filename + ".txt"), "w") as fp:
            json.dump(data,fp)
        
        with open(os.path.join(path_data,filename + "_time.log"), "w") as fp:
            json.dump("Seconds it took to generate the graphs in " + str(filename) + " : " + str(graph_time),fp)
            fp.write('\n')
            json.dump("Seconds it took to calculate their ECCNs: " + str(eccn_time),fp)