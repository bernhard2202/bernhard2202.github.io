import random
import numpy as np
import networkx as nx
from networkx import DiGraph
import itertools
import matplotlib.pyplot as plt

##Erdös-Rényi (ER) random graph generator (as adj matrix)
#n = number vertices
#p = probablity of a directed edge between any nonequal vertices, default: undirected
def rand_graph_erp(n, p, directed):
    graph = [[0 for x in range(n)] for x in range(n)]
    if directed == True:
        for i in range(n):
            for j in range(n):
                if i != j:
                    rand = random.uniform(0,1)
                    if rand < p:
                        graph[i][j] = 1
    else:
        for i in range(n):
            for j in range(i):
                if i != j:
                    rand = random.uniform(0,1)
                    if rand < p:
                        graph[i][j] = 1
                        graph[j][i] = 1
    return graph

#makes networkx graph from adj matrix
def nx_graph_from_adj_matrix(graph_adj):
     graph_matrix = np.matrix(graph_adj)
     graph_nx = nx.from_numpy_matrix(graph_matrix)
     return(graph_nx.to_directed())

#creates complete graph from a list of node labels
def complete_graph_from_list(L, create_using=None):
    G = nx.empty_graph(len(L),create_using)
    if len(L)>1:
        if G.is_directed():
            edges = itertools.permutations(L,2)
        else:
            edges = itertools.combinations(L,2)
        G.add_edges_from(edges)
    return G.to_directed()

#calculates ECCN with Bron-Kerbosch to find all maximal cliques and brute force minimal cover
def ECCN(graph_nx):
    graph_nx = graph_nx.to_directed()
    if list(graph_nx.edges()) == []:
        return(0)
    else:
        n = DiGraph.number_of_nodes(graph_nx)
        max_eccn = int(np.floor(n**2/4))
        undirected_graph_nx = graph_nx.to_undirected()
        cliques = list(nx.find_cliques(undirected_graph_nx))
        
        #print('Edges of the input graph:',graph_nx.edges())
        #print('Number of maximal cliques in the graph:',len(cliques))
        #print('The maximal cliques are:')
        #for clique in cliques:
        #    print(clique)
        
        #list of edges sets of cliques
        edges = []
        for clique in cliques:
            edges.append(set(complete_graph_from_list(clique).edges()))
        
        #print('The edges of the cliques are:',edges)
        
        #try if any 1,2,3,... of them cover the original edges
        for i in range(max_eccn+1):
            #try every subset of cliques of cardinality i
            generator_comb = itertools.combinations(edges,i)
            for collection_cliques_edges in generator_comb:
                #print('Combination of',i,'cliques in edges:',collection_cliques_edges)
                covered_edges = set()
                #unify edges of subset of cliques
                for clique_edges in collection_cliques_edges:
                    covered_edges = covered_edges | clique_edges
                #print('Edges that became covered:',covered_edges)
                #print('Edges of the graph',graph_nx.edges())
                #print('Uncovered edges:', (covered_edges | set(graph_nx.edges())) - (covered_edges & set(graph_nx.edges())))
                #print('All original edges covered?:', covered_edges == graph_nx.edges())
                if covered_edges == graph_nx.edges():
                    #print('The following cliques cover all edges',collection_cliques_edges)
                    #print('Edges covered',covered_edges)
                    return(i)
                
def ECCN_from_adj(graph_adj):
    eccn = ECCN(nx_graph_from_adj_matrix(graph_adj))
    return([graph_adj,eccn])
                
#generates ER random graphs with p=0.5 and calculates their ECCN; used for data generation
#def ER_ECCN(n,_):
#        graph = list(rand_graph_erp(n, 0.5, directed = False))
#        eccn = ECCN(nx_graph_from_adj_matrix(graph))
#        return [graph,eccn]
                

#ECCN heuristic by Kellerman and Kou
#only input directed nx graphs (both directions of edges are needed)
def KelKou_ECCN(graph_nx):
    #k: number of generated cliques; C: list of k Cliques as sets
    k = 0
    C = []
    n = DiGraph.number_of_nodes(graph_nx)
    for i in range(n):
        #print("\n")
        #print("I am at vertex:", i)
        W = []
        #G: set of vertices with lower label that are connected to node i
        for j in range(i):
            if graph_nx.has_edge(i,j) == True:
                W.append(j)
        W = set(W)
        #print("Edges to vertices with lower label:", W)    
        #create new clique for i if W is empty
        if len(W) == 0:
            C.append(set([i])) #C[k] = set([i])
            k = k+1
            #print("I have created a new clique because it did not have any edges. This was clique number:", len(C))
        else:
            m = 0
            V = set([])
            #try to add vertex to existing cliques
            while m < k and V != W:
                if C[m] <= W: #<= is also subset
                    C[m] = C[m]|set([i])
                    print("I added the vertex to clique:",C[m])
                    V = V|C[m]
                m = m+1
            W = W-V #setminus
            #create new cliques to cover remaining edges
            #print("The edge to these vertices are still uncovered after trying to add vertex to cliques:",W)
            while len(W) > 0:
                l_min = 0
                card_max = 0
                for l in range(k):
                    if card_max < len(C[l]&W): #set intersection
                        card_max = len(C[l]&W)
                        l_min = l
                C.append((C[l_min]&W)|set([i])) #C[k] = (C[l_min]&W)|set([i])
                #print("I have created a new clique to cover a bunch of remaining edges:", (C[l_min]&W)|set([i]))
                #print("This was clique number:",len(C))
                W = W-C[l_min]
                k = k+1
    #here len(C) would be the solution by Kel
    #from here postprocession proposed by Kou
    edges_cliques = []
    for clique in C:
            edges_cliques.append(set(complete_graph_from_list(clique).edges()))
    #print(edges_cliques)
    edges_cliques2 = list(edges_cliques)
    for clique in edges_cliques:
        #print('I am at clique', clique)
        edges_cliques_without_this_clique = list(edges_cliques)
        edges_cliques_without_this_clique.remove(clique)
        #print("Before error:", edges_cliques_without_this_clique)
        if len(edges_cliques_without_this_clique) > 0:
            covered_edges_without_this_clique = set.union(*edges_cliques_without_this_clique)
            #print("After error:", covered_edges_without_this_clique)
            if clique <= covered_edges_without_this_clique:
                edges_cliques2.remove(clique)
                #print("This clique could be removed via postprocessing:",clique)
    return(len(edges_cliques2))

def KelKou_ECCN_from_adj(graph_adj):
     eccnheu = KelKou_ECCN(nx_graph_from_adj_matrix(graph_adj))
     return [graph_adj,eccnheu]
    

###############################################################################            
##Examples to test
# use nx.draw(G) to draw graphs; G is a graph_nx

#Example 1: Die; eccn should be 5 (6 are all sides)
#die =[[0,1,1,1,1,1,1,0],
#      [1,0,1,1,1,1,0,1],
#      [1,1,0,1,1,0,1,1],
#      [1,1,1,0,0,1,1,1],
#      [1,1,1,0,0,1,1,1],
#      [1,1,0,1,1,0,1,1],
#      [1,0,1,1,1,1,0,1],
#      [0,1,1,1,1,1,1,0]]
#die_nx = nx_graph_from_adj_matrix(die)

#Example 2: Two Triagles with one shared edge
#easy = [[0,1,1,1],[1,0,1,1],[1,1,0,0],[1,1,0,0]]
#easy_nx = nx_graph_from_adj_matrix(easy)

#Example 3: Two unconnected edges and 4 nodes
#twoedge = [[0,1,0,0],[1,0,0,0],[0,0,0,1],[0,0,1,0]]
#twoedge_nx = nx_graph_from_adj_matrix(twoedge)

#Example 4: Triangle and isolated vertex
#tri = [[0,1,1,0],[1,0,1,0],[1,1,0,0],[0,0,0,0]]
#tri_nx = nx_graph_from_adj_matrix(tri)

#Example 5: Sparse graph
#sparse = [[0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 1, 0, 0, 1, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#          [1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
#sparse_nx = nx_graph_from_adj_matrix(sparse)

#Example 6: Dense graph
#dense = [[0, 1, 1, 1, 1, 1, 1],
#         [1, 0, 1, 1, 1, 1, 1],
#         [1, 1, 0, 1, 1, 1, 1],
#         [1, 1, 1, 0, 1, 1, 1],
#         [1, 1, 1, 1, 0, 1, 1],
#         [1, 1, 1, 1, 1, 0, 1],
#         [1, 1, 1, 1, 1, 1, 0]]
#dense_nx = nx_graph_from_adj_matrix(dense)
###############################################################################

##ER graph plots
def drawGraph(G,filename):
    f = plt.figure(figsize=(10,10))
    nx.draw_circular(G,
                   arrows = False,
                   with_labels = False,
                   node_size = 1000,
                   #%node_color = '#3333B2',#%UniFreiburg
                   #node_color = '#1268B0', #%ETHZürich
                   node_color = '#808080', #grey
                   alpha = 1,
                   style = 'solid',
                   font_size = 12,
                   font_color = 'white',
                   ax = f.add_subplot(111))
    f.savefig(filename)

sparse = nx_graph_from_adj_matrix(rand_graph_erp(10,0.1,False))
#nx.draw_circular(sparse)

medium = nx_graph_from_adj_matrix(rand_graph_erp(10,0.5,False))
#nx.draw_circular(medium)

dense = nx_graph_from_adj_matrix(rand_graph_erp(10,0.9,False))
#nx.draw_circular(dense)

    
drawGraph(sparse,"testgraph_sparse.pdf")
drawGraph(medium,"testgraph_medium.pdf")
drawGraph(dense,"testgraph_dense.pdf")





















