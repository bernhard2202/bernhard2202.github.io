#calculates Kellerman and Kou heuristic from file data generated with genererate_ER_CCN

import numpy as np
import os.path
import json
import time
from multiprocessing import Pool
from functions_graphs import KelKou_ECCN_from_adj
from sklearn.metrics import mean_squared_error, mean_absolute_error, accuracy_score

#print whole arrays
np.set_printoptions(threshold=np.nan)

if __name__ == '__main__':
    #set time counter
    start_time = time.time()

    ##variable
    #number of nodes in each graph, takes a list
    graphsizes = [12]
    #number of samples for each size
    samplesize = 50000
    #set to dense9, dense 5 or sparse1
    connection_type = "dense5"
    
###############################################################################    
    
    filenames = ["ER_ECCN_" + str(connection_type) + "_" + str(graphsize) + "_" + str(samplesize) for graphsize in graphsizes]
    path_data = os.path.join(os.path.join(os.path.dirname(os.getcwd()),"Data"), str(connection_type))
    
    for filename in filenames:
        #read data from file
        with open(os.path.join(path_data,filename + ".txt"), "r") as fp:
            data = json.load(fp)
        X = [data[i][0] for i in range(samplesize)]
        y = [data[i][1] for i in range(samplesize)] #actual ECCN
        
        #size of graphs in the current file
        graphsize = len(X[0])
        
        #calculate Kel Kou heuristical solutions in parallel
        pool = Pool(processes=4)
        data = pool.starmap(KelKou_ECCN_from_adj, [[graph] for graph in X])
        pool.close()
        pool.join()
        
        #heuristical solutions
        yheu = [data[i][1] for i in range(samplesize)]
        
        #time stamp for data generation        
        time_now = time.time()
        ex_time = time_now - start_time
        
        #write data to file
        with open(os.path.join(path_data,filename + "_KelKouHeu.txt"), "w") as fp:
            json.dump(data,fp)
        
        with open(os.path.join(path_data,filename + "_KelKouHeu_time.log"), "w") as fp:
            json.dump("Seconds calculate Kellerman and Kou heuristic for file " + str(filename) + " : " + str(ex_time),fp)
        
        #performance of heuristic (MSE, MAE, ACC on all, train, val, and test data)
        split_train = int(.7 * samplesize)
        split_validation = int(.1 *samplesize) + split_train
            
        yheu_train = yheu[:split_train]
        y_train = y[:split_train]
        
        yheu_validation = yheu[split_train:split_validation]
        y_validation = y[split_train:split_validation]
        
        yheu_test = yheu[split_validation:]
        y_test = y[split_validation:]
        
        with open(os.path.join(path_data,filename + "_KelKouHeu_performance.log"), "w") as fp:
            json.dump("Performance of KelKou heuristics for file " + str(filename),fp)
            fp.write("\n\n")
            
            json.dump("ALL DATA",fp)
            fp.write("\n")
            json.dump("MSE in all data: " + str(mean_squared_error(y, yheu)),fp)
            fp.write("\n")
            json.dump("MAE in all data: " + str(mean_absolute_error(y, yheu)),fp)
            fp.write("\n")
            json.dump("ACC in all data: " + str(accuracy_score(y, yheu, normalize=True)),fp)
            fp.write("\n\n")
            
            json.dump("TRAIN DATA",fp)
            fp.write("\n")
            json.dump("MSE in train data: " + str(mean_squared_error(y_train, yheu_train)),fp)
            fp.write("\n")
            json.dump("MAE in train data: " + str(mean_absolute_error(y_train, yheu_train)),fp)
            fp.write("\n")
            json.dump("ACC in train data: " + str(accuracy_score(y_train, yheu_train, normalize=True)),fp)
            fp.write("\n\n")
            
            json.dump("VALIDATION DATA",fp)
            fp.write("\n")
            json.dump("MSE in validation data: " + str(mean_squared_error(y_validation, yheu_validation)),fp)
            fp.write("\n")
            json.dump("MAE in validation data: " + str(mean_absolute_error(y_validation, yheu_validation)),fp)
            fp.write("\n")
            json.dump("ACC in validation data: " + str(accuracy_score(y_validation, yheu_validation, normalize=True)),fp)
            fp.write("\n\n")
            
            json.dump("TEST DATA",fp)
            fp.write("\n")
            json.dump("MSE in test data: " + str(mean_squared_error(y_test, yheu_test)),fp)
            fp.write("\n")
            json.dump("MAE in test data: " + str(mean_absolute_error(y_test, yheu_test)),fp)
            fp.write("\n")
            json.dump("ACC in test data: " + str(accuracy_score(y_test, yheu_test, normalize=True)),fp)
       
        
        