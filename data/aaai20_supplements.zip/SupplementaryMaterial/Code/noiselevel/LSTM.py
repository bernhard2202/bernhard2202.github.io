import numpy as np
##set random seed before import of keras moduls
np.random.seed(229156044)

from keras.callbacks import CSVLogger, EarlyStopping, ModelCheckpoint
from keras.models import Sequential
from keras.layers import Dense, LSTM
from keras import backend as K
from keras import optimizers
from keras import initializers
from keras.models import load_model
import os.path
import json
import tensorflow as tf
import random
from sklearn.utils import shuffle
from sklearn.metrics import mean_absolute_error, mean_squared_error
random.seed(229156044)

##print whole arrays
np.set_printoptions(threshold=np.nan)

#number of vertices in each graph
graphsizes = [10,11,12]
#number of samples for each size (has to be the same for every size)
samplesize = 50000
#set to dense9, dense 5 or sparse1
connection_types = ["dense9"]
hidden_units = [1024]
#patience
patience_earystop = 20

#%%
batchsize = 128
epochs =  2000 #at most

def ensure_dir(directory):
    print(directory)
    if not os.path.exists(directory):
        os.makedirs(directory)

def soft_acc(y_true, y_pred):
    y_true = tf.exp(y_true)
    y_pred = tf.exp(y_pred)
    return K.mean(K.equal(K.round(y_true), K.round(y_pred)))



path_output_root = os.path.join(os.path.dirname(os.getcwd()), "Output", "noiselevel_LSTM")
ensure_dir(path_output_root)

for connection_type in connection_types:
    print("Start experiments for connection type: {}".format(connection_type))
    path_output = os.path.join(path_output_root, connection_type)
    ensure_dir(path_output)

    path_data = os.path.join(os.path.join(os.path.dirname(os.getcwd()), "Data"), str(connection_type))
    filename = "ER_ECCN_padded_" + str(connection_type) + "_" + str(graphsizes) + "_" + str(samplesize)
    X = np.load(os.path.join(path_data, filename + "_X.npy"))
    y = np.load(os.path.join(path_data, filename + "_y.npy"))

    X, y = shuffle(X, y, random_state=42)

    ##split data (0.7,0.1,0.2)
    split_train = int(.7 * len(y))
    split_validation = int(.1 * len(y)) + split_train

    X_train = X[:split_train]
    y_train_ = y[:split_train]

    X_validation = X[split_train:split_validation]
    y_validation_ = y[split_train:split_validation]

    X_test = X[split_validation:]
    y_test_ = y[split_validation:]

    for noise_level in range(1,8,2):

        y_train = y_train_ + np.random.normal(0, noise_level/10, (len(y_train_)))
        offset = 0
        if np.min(y_train) <= 0:
            offset = np.ceil(1-np.min(y_train))

        y_train = np.log(np.add(y_train,offset))
        y_validation = np.log(np.add(y_validation_,offset))
        y_test = np.log(np.add(y_test_,offset))
        best_score = -1
        best = []


        for hidden_size in hidden_units:
            print("check HU = {}".format(hidden_size))
            lr = 0.001
            ##optimizer: adam
            #learning_rate = 0.001
            opt = optimizers.Adam(lr=lr)

            #%%
            ##define and initialize model
            model = Sequential()
            model.add(LSTM(hidden_size,
                           input_shape = (X_train.shape[1],X_train.shape[2]),
                           activation='tanh',
                           recurrent_activation='hard_sigmoid',
                           use_bias=True,
                           kernel_initializer='glorot_uniform',
                           recurrent_initializer='orthogonal',
                           bias_initializer='zeros',
                           unit_forget_bias=True,
                           kernel_regularizer=None,
                           recurrent_regularizer=None,
                           bias_regularizer=None,
                           activity_regularizer=None,
                           kernel_constraint=None,
                           recurrent_constraint=None,
                           bias_constraint=None,
                           dropout=0.0,
                           recurrent_dropout=0.0,
                           implementation=1,
                           return_sequences=False,
                           go_backwards=False,
                           stateful=False,
                           unroll=False))
            model.add(Dense(1,
                            activation = None,
                            use_bias = True,
                            kernel_initializer = 'glorot_uniform',
                            bias_initializer = initializers.Constant(value=0.1),
                            kernel_regularizer = None,
                            bias_regularizer = None,
                            activity_regularizer = None,
                            kernel_constraint = None,
                            bias_constraint = None))

            early_stop = EarlyStopping(monitor='val_soft_acc',
                                       min_delta=0,
                                       patience=20,
                                       verbose=0,
                                       mode='max')
            bestmodelname = os.path.join(path_output, '{}_{}_bestmodel.h5'.format(noise_level, hidden_size))
            save_best = ModelCheckpoint(bestmodelname,
                                        monitor='val_soft_acc',
                                        verbose=0,
                                        save_best_only=True,
                                        mode='max')
            ##train model
            model.compile(optimizer=opt,
                          loss='mean_squared_error',
                          metrics=['mean_absolute_error', soft_acc])


            model.fit(X_train,
                      y_train,
                      epochs = epochs,
                      batch_size = batchsize,
                      validation_data = (X_validation,y_validation),
                      verbose = 2,
                      shuffle = True,
                      callbacks = [ save_best, early_stop])

            ##load best_model
            best_model = load_model(bestmodelname, custom_objects={'soft_acc': soft_acc})

            curr_score = best_model.evaluate(X_test, y_test)[2]
            print("scored {}".format(curr_score))
            if best_score < curr_score:
                ##scores of the best model
                best_score = curr_score
                y_pred = np.exp(best_model.predict(X_test))
                mse = mean_squared_error(np.exp(y_test), y_pred)
                mae = mean_absolute_error(np.exp(y_test), y_pred)
                best_score = curr_score
                best = [best_model.evaluate(X_train, y_train),
                        best_model.evaluate(X_validation, y_validation),
                        best_model.evaluate(X_test, y_test),
                        mae,
                        mse]
            os.remove(bestmodelname)
        with open(os.path.join(path_output, 'fraction_{}_performance.log'.format(noise_level)), "w") as fp:
            json.dump(best, fp)



