Appendix.pdf - > The appendix to the main paper


Code/ : folder with source code for experiments

 ---> kel_heuristic.py : calculate state-of-the-art heuristic solutions for graphs
 ---> generat_ER_ECCN.py : geneates ER graphs and calculates the exact ECCN solution for them
 ---> functions_graphs.py : algorithms and helpers for the above

 Code/samplesize_complexity/ : code for samplesize complexity experiment 

 ---> samplesize_complexity/LSTM.py : long short term memory network code
 ---> samplesize_complexity/RNN.py : recurrent neural network code
 ---> samplesize_complexity/FNN.py : feed forward neural network code

 Code/noiselevel/ : code for noise level experiments
